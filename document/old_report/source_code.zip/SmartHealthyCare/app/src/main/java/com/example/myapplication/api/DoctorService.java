package com.example.myapplication.api;

import com.example.myapplication.api.request.SearchRequest;
import com.example.myapplication.api.request.TimeSlotRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Doctor;
import com.example.myapplication.models.TimeSlot;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DoctorService {
    @POST("doctors/search-doctors")
    Call<ApiResponse<List<Doctor>>> search(@Body SearchRequest searchRequest);

    @GET("time-slots/doctor/{doctorId}/available-by-date")
    Call<ApiResponse<List<TimeSlot>>> getTimeSlotForDoctorAtDate(@Path("doctorId") int doctorId,
                                                                 @Query("date") String date);

    @POST("time-slots/create")
    Call<ApiResponse<List<TimeSlot>>> createTimeSlot(@Body TimeSlotRequest timeSlotRequest);

}
