package com.example.myapplication.api;

import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.EHR;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface EHRService {
    @GET("ehr/user/{id}")
    Call<ApiResponse<EHR>> getEHR(@Path("id") String id);


}
