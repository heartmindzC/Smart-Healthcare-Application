package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.AppointmentService;
import com.example.myapplication.api.DoctorService;
import com.example.myapplication.api.PatientService;
import com.example.myapplication.api.request.AppointmentPreInformation;
import com.example.myapplication.api.request.AppointmentRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Appointment;
import com.example.myapplication.models.Patient;
import com.example.myapplication.models.TimeSlot;
import com.example.myapplication.utilities.LoginManager;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConfirmAppointmentActivity extends AppCompatActivity {
    MaterialToolbar toolbar;
    TextView tvDoctorName, tvPatientName, tvHospitalName, tvDepartment, tvSpecificTime;
    EditText etNote, etReason;
    Button btConfirm;

    private int doctorId;
    private int patientId;
    private String patientName;
    private String doctorName;
    private int hospitalId;
    private String hospitalName;
    private Integer departmentId;
    private String departmentName;
    private String appointmentDateTime;
    private int timeSlotId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_confirm_appointment);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        toolbar = findViewById(R.id.materialToolbar2);
        tvDoctorName   = findViewById(R.id.tvDoctorName);
        tvPatientName  = findViewById(R.id.tvPatientName);
        tvHospitalName = findViewById(R.id.tvHospitalName);
        tvDepartment   = findViewById(R.id.tvDepartment);
        tvSpecificTime = findViewById(R.id.tvSpecificTime);
        etNote   = findViewById(R.id.etNote);
        etReason = findViewById(R.id.etReason);
        btConfirm = findViewById(R.id.btConfirm);

        Intent intent = getIntent();
        doctorId = intent.getIntExtra("doctorId", 0);
        hospitalId = intent.getIntExtra("hospitalId", 0);
        doctorName = intent.getStringExtra("doctorName");
        hospitalName = intent.getStringExtra("hospitalName");
        departmentName = intent.getStringExtra("departmentName");
        appointmentDateTime = intent.getStringExtra("appointmentDateTime");
        departmentId = intent.getIntExtra("departmentId", -1);
        timeSlotId = intent.getIntExtra("timeSlotId", -1);

        tvDoctorName.setText(doctorName);
        tvHospitalName.setText(hospitalName);
        tvDepartment.setText(departmentName);
        if (appointmentDateTime != null && !appointmentDateTime.isEmpty()) {

            int tIndex = appointmentDateTime.indexOf('T');

            if (tIndex != -1) {
                String datePart = appointmentDateTime.substring(0, tIndex); // "2025-12-15"
                String timePart = appointmentDateTime.substring(tIndex + 1); // "14:30:00"


                String displayTime = timePart.substring(0, 5);

                tvSpecificTime.setText(displayTime + " on " + datePart);
            } else {
                tvSpecificTime.setText(appointmentDateTime);
            }
        } else {
            tvSpecificTime.setText("Thời gian chưa được xác định");
        }

        callApiGetPatientInfo();

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String note = etNote.getText().toString();
                String reason = etReason.getText().toString();

                AppointmentRequest appointmentRequest = new AppointmentRequest(
                        doctorId,
                        doctorName,
                        patientId,
                        patientName,
                        hospitalId,
                        hospitalName,
                        departmentId,
                        departmentName,
                        timeSlotId,
                        appointmentDateTime,
                        note,
                        reason
                );

                callApiCreateAppointment(appointmentRequest);
            }
        });
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
        finish();
    }

    private void callApiCreateAppointment(AppointmentRequest appointmentRequest) {
        AppointmentService appointmentService = ApiClient.getClient().create(AppointmentService.class);
        Call<ApiResponse<List<Appointment>>> call = appointmentService.create(appointmentRequest);

        call.enqueue(new Callback<ApiResponse<List<Appointment>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Appointment>>> call, Response<ApiResponse<List<Appointment>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<List<Appointment>> apiResponse = response.body();

                    if (apiResponse.isStatus()) {
                        Toast.makeText(ConfirmAppointmentActivity.this, "REQUIRE WAS SENT, CHECK STATUS", Toast.LENGTH_SHORT).show();
                        checkAppointment(apiResponse.getResult().get(0));
                        Log.d("API APPOINTMENT RESPONSE","CREATE APPOINTMENT SUCCESS");
                        changeScreen(HomeAcitivity.class);
                    }
                    else {
                        Log.d("API APPOINTMENT RESPONSE","API RESPONSE STATUS FALSE");
                    }
                }
                else {
                    Log.d("API APPOINTMENT RESPONSE","RESPONSE IS NULL");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Appointment>>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void checkAppointment(Appointment appointment) {
        DoctorService doctorService = ApiClient.getClient().create(DoctorService.class);
        Call<ApiResponse<List<TimeSlot>>> call = doctorService.getTimeSlotForDoctorAtDate(appointment.getDoctorId(), appointment.getAppointmentDateTime().substring(0, 10));

        call.enqueue(new Callback<ApiResponse<List<TimeSlot>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<TimeSlot>>> call, Response<ApiResponse<List<TimeSlot>>> response) {
                if (response.isSuccessful() && response.body() != null ) {
                    ApiResponse<List<TimeSlot>> apiResponse = response.body();

                    if (!apiResponse.isStatus()) {
                        Log.d("CHECK APPOINTMENT","API RESPONSE STATUS FALSE");
                        // confirm appointment
                        confirmAppointment(appointment.getAppointmentId());
                    }
                    else {
                        Log.d("CHECK APPOINTMENT","API RESPONSE STATUS TRUE");
                        // check start time của appointment != của apiRespnose thì nhân else cancel
                        List<TimeSlot> timeSlots = apiResponse.getResult();

                        for (TimeSlot i: timeSlots){
                            if (i.getStartTime().toString().equals(appointment.getAppointmentDateTime().toString().substring(11, 19)) && !i.getTimeSlotId().equals(appointment.getTimeSlotId())){
                                cancelAppointment(appointment.getAppointmentId());
                                return;
                            }
                        }

                        // confirm
                        confirmAppointment(appointment.getAppointmentId());
                    }
                }
                else {
                    Log.d("ConfirmAppointmentActivity:", "RESPONSE IS NULL");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<TimeSlot>>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
    private void cancelAppointment(int appointmentId) {
        AppointmentService appointmentService = ApiClient.getClient().create(AppointmentService.class);
        Call<ApiResponse<List<Appointment>>> call = appointmentService.cancelAppointment(appointmentId);

        call.enqueue(new Callback<ApiResponse<List<Appointment>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Appointment>>> call, Response<ApiResponse<List<Appointment>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("ConfirmAppointmentActivity:", "APPOINTMENT CANCEL");
                }
                else {
                    Log.d("ConfirmAppointmentActivity:", "RESPONSE IS NULL");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Appointment>>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }


    private void confirmAppointment(int appointmentId) {
        AppointmentService appointmentService = ApiClient.getClient().create(AppointmentService.class);
        Call<ApiResponse<List<Appointment>>> call = appointmentService.confirmAppointment(appointmentId);

        call.enqueue(new Callback<ApiResponse<List<Appointment>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Appointment>>> call, Response<ApiResponse<List<Appointment>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("ConfirmAppointmentActivity:", "APPOINTMENT CONFIRM");
                }
                else {
                    Log.d("ConfirmAppointmentActivity:", "RESPONSE IS NULL");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Appointment>>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void callApiGetPatientInfo() {
        PatientService patientService = ApiClient.getClient().create(PatientService.class);
        Call<Patient> call = patientService.getPatientTemp(LoginManager.getUser().getUserId());

        call.enqueue(new Callback<Patient>() {
            @Override
            public void onResponse(Call<Patient> call, Response<Patient> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Patient patient = response.body();
                    patientName = patient.getFullName();
                    patientId = patient.getPatientId();

                    tvPatientName.setText(patientName);
                }
                else {
                    Log.d("API PATIENT RESPONSE", "RESPONSE IS NULL");
                }
            }

            @Override
            public void onFailure(Call<Patient> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}