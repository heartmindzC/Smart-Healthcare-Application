package com.example.myapplication.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.DoctorService;
import com.example.myapplication.api.request.AppointmentPreInformation;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Doctor;
import com.example.myapplication.models.Time;
import com.example.myapplication.models.TimeSlot;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorHolder> {
    private final String LOG_TAG_TIME_SLOT = "AppointmentReservation:TIME_SLOT";
    private final String LOG_MESSAGE_CALL_API_FAILED = "CALL API FAILED";
    private final String LOG_MESSAGE_CALL_API_SUCCESS = "CALL API SUCCESS";
    private final String LOG_MESSAGE_API_STATUS_TRUE = "API_STATUS_TRUE";
    private final String LOG_MESSAGE_API_STATUS_FALSE = "API_STATUS_FALSE";
    private final String LOG_MESSAGE_RESPONSE_NULL = "RESPONSE IS NULL OR NOT SUCCESS";
    private final String TOAST_MESSAGE = "CAN NOT LOAD DATA";
    private AppointmentPreInformation appointmentPreInformation;
    TimeAdapter timeAdapter;
    String date;
    List<Doctor> doctors;
    Context context;
    List<Time> times;

    public DoctorAdapter(List<Doctor> doctors, Context context, String date, AppointmentPreInformation appointmentPreInformation) {
        this.doctors = doctors;
        this.context = context;
        this.date = date;
        this.appointmentPreInformation = appointmentPreInformation;
    }

    @NonNull
    @Override
    public DoctorHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.doctor_information_item, parent, false);
        return new DoctorHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DoctorHolder holder, int position) {
        Doctor doctor = doctors.get(position);

        holder.tvName.setText(doctor.getFullName());
        holder.tvDepartment.setText(doctor.getDepartment());
        holder.btShowTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.rvAvailableTime.getVisibility() == View.GONE) {
                    holder.rvAvailableTime.setVisibility(View.VISIBLE);
                    appointmentPreInformation.setDoctorName(doctor.getFullName());
                    appointmentPreInformation.setDoctorId(doctor.getDoctorId());
                }
                else {
                    holder.rvAvailableTime.setVisibility(View.GONE);
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appointmentPreInformation.setDoctorName(doctor.getFullName());
                appointmentPreInformation.setDoctorId(doctor.getDoctorId());
            }
        });

        holder.rvAvailableTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appointmentPreInformation.setDoctorName(doctor.getFullName());
                appointmentPreInformation.setDoctorId(doctor.getDoctorId());
            }
        });


        DateTimeFormatter timeFormatter = null;
        LocalDate localDate = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            localDate = LocalDate.now();
        }

        times = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                localDate = LocalDate.parse(date);

            } catch (java.time.format.DateTimeParseException e) {
                System.err.println("Lỗi: Định dạng chuỗi không hợp lệ.");
            }

            timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

            times.add(new Time(
                    doctor.getDoctorId(),
                    doctor.getFullName(),
                    "9:00 - 10:00",                                         // time
                    LocalTime.parse("09:00", timeFormatter),               // startTime
                    LocalTime.parse("10:00", timeFormatter),               // endTime
                    localDate,                                           // date
                    true                                                   // isAvailable
            ));
            times.add(new Time(
                    doctor.getDoctorId(),
                    doctor.getFullName(),
                    "10:30 - 11:30",
                    LocalTime.parse("10:30", timeFormatter),
                    LocalTime.parse("11:30", timeFormatter),
                    localDate,
                    true
            ));
            times.add(new Time(
                    doctor.getDoctorId(),
                    doctor.getFullName(),
                    "12:30 - 13:30",
                    LocalTime.parse("12:30", timeFormatter),
                    LocalTime.parse("13:30", timeFormatter),
                    localDate,
                    true
            ));
            times.add(new Time(
                    doctor.getDoctorId(),
                    doctor.getFullName(),
                    "14:00 - 15:00",
                    LocalTime.parse("14:00", timeFormatter),
                    LocalTime.parse("15:00", timeFormatter),
                    localDate,
                    true
            ));
            times.add(new Time(
                    doctor.getDoctorId(),
                    doctor.getFullName(),
                    "15:30 - 16:30",
                    LocalTime.parse("15:30", timeFormatter),
                    LocalTime.parse("16:30", timeFormatter),
                    localDate,
                    true
            ));
        }
        getAvailableTime(doctor.getDoctorId(), date, holder.rvAvailableTime);
    }

    private void loadRecyclerView(RecyclerView rv) {
        rv.setAdapter(timeAdapter);
        rv.setLayoutManager(new GridLayoutManager(context, 3));
    }

    private void getAvailableTime(int doctorId, String date, RecyclerView rv) {
        DoctorService doctorService = ApiClient.getClient().create(DoctorService.class);
        Call<ApiResponse<List<TimeSlot>>> call = doctorService.getTimeSlotForDoctorAtDate(doctorId, date);

        Log.d("LOG", date + " " + doctorId);

        call.enqueue(new Callback<ApiResponse<List<TimeSlot>>>() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onResponse(Call<ApiResponse<List<TimeSlot>>> call, Response<ApiResponse<List<TimeSlot>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<List<TimeSlot>> apiResponse = response.body();

                    if (apiResponse.isStatus()) {
                        List<TimeSlot> timeSlots = apiResponse.getResult();

                        for (TimeSlot i: timeSlots) {
                            for (Time j:times) {
                                if (i.getStartTime().substring(0, 5).equals(j.getStartTime().toString())) {
                                    j.setAvailable(false);
                                    timeAdapter = new TimeAdapter(times, context, appointmentPreInformation, date);
                                    loadRecyclerView(rv);
                                }
                            }
                        }
                    }
                    else {
                        Log.d(LOG_MESSAGE_CALL_API_SUCCESS, LOG_MESSAGE_API_STATUS_FALSE);
                        timeAdapter = new TimeAdapter(times, context, appointmentPreInformation, date);
                        loadRecyclerView(rv);
                    }
                }
                else {
                    Log.d(LOG_TAG_TIME_SLOT, LOG_MESSAGE_RESPONSE_NULL);
                    Toast.makeText(context, TOAST_MESSAGE, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<TimeSlot>>> call, Throwable t) {
                t.printStackTrace();
                Log.d(LOG_TAG_TIME_SLOT, LOG_MESSAGE_CALL_API_FAILED);
                Toast.makeText(context, "CHECK YOUR INTERNET CONNECTION", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return doctors.size();
    }
}
