package com.example.myapplication;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapters.DepartmentSpinnerAdapter;
import com.example.myapplication.adapters.DoctorAdapter;
import com.example.myapplication.adapters.HospitalSpinnerAdapter;
import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.DoctorService;
import com.example.myapplication.api.request.AppointmentPreInformation;
import com.example.myapplication.api.request.SearchRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.api.HospitalService;
import com.example.myapplication.models.Department;
import com.example.myapplication.models.Doctor;
import com.example.myapplication.models.Hospital;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AppointmentReservationActivity extends AppCompatActivity {
    private final String LOG_TAG_SEARCH = "AppointmentReservationActivity:SEARCH";
    private final String LOG_TAG_HOSPITAL = "AppointmentReservationActivity:HOSPITAL";
    private final String LOG_TAG_DEPARTMENT = "AppointmentReservationActivity:DEPARTMENT";
    AppointmentPreInformation appointmentPreInformation;
    MaterialToolbar toolbar;
    EditText etDate;
    RecyclerView rvDoctors;
    String dateString;
    Button btSearch;
    Spinner spinner_options, spinner_options2;
    private int hospitalId = -1;
    private String departmentName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_appointment_reservation);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Khai báo
        toolbar = findViewById(R.id.materialToolbar2);
        etDate = findViewById(R.id.etDate);
        spinner_options = findViewById(R.id.spinner_options);
        spinner_options2 = findViewById(R.id.spinner_options2);
        btSearch = findViewById(R.id.btSearch);
        rvDoctors = findViewById(R.id.rvDoctors);

        appointmentPreInformation = new AppointmentPreInformation();

        // goi cac function o day
        callAPIHospital();

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hospitalId == -1) {
                    Toast.makeText(AppointmentReservationActivity.this, "Select hospital", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_SEARCH, "SELECT HOSPITAL IS NOT SELECTED");
                    return;
                }

                if (departmentName.isEmpty()) {
                    Toast.makeText(AppointmentReservationActivity.this, "Select department", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_SEARCH, "SELECT DEPARTMENT IS NOT SELECTED");
                    return;
                }

                if (dateString == null || dateString.isEmpty()) {
                    Toast.makeText(AppointmentReservationActivity.this, "Select Date", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_SEARCH, "DATE IS NOT SELECTED");
                    return;
                }

                search(hospitalId, departmentName);

            }
        });
    }

    private void search(int hospitalId, String departmentName) {
        SearchRequest searchRequest = new SearchRequest(hospitalId, departmentName);

        DoctorService doctorService = ApiClient.getClient().create(DoctorService.class);
        Call<ApiResponse<List<Doctor>>> call = doctorService.search(searchRequest);

        call.enqueue(new Callback<ApiResponse<List<Doctor>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Doctor>>> call, Response<ApiResponse<List<Doctor>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<List<Doctor>> apiResponse = response.body();

                    if (apiResponse.isStatus()) {
                        List<Doctor> doctors = apiResponse.getResult();

                        loadRecyclerView(doctors);
                    }
                    else {
                        Log.d(LOG_TAG_SEARCH, "API STATUS FALSE");
                        Toast.makeText(AppointmentReservationActivity.this, "DATA EMPTY", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d(LOG_TAG_SEARCH, "RESPONSE NULL OR NOT SUCCESS");
                    Toast.makeText(AppointmentReservationActivity.this, "CANNOT LOAD DATA", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Doctor>>> call, Throwable t) {
                t.printStackTrace();
                Log.d(LOG_TAG_SEARCH, "CALL API ERROR");
                Toast.makeText(AppointmentReservationActivity.this, "CHECK YOUR INTERNET CONNECTION", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void callAPIHospital() {
        Log.d(LOG_TAG_HOSPITAL, "CALL API HOSPITAL PROCESS");
        HospitalService hospitalService = ApiClient.getClient().create(HospitalService.class);
        Call<ApiResponse<List<Hospital>>> call = hospitalService.getAll();

        call.enqueue(new Callback<ApiResponse<List<Hospital>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Hospital>>> call, Response<ApiResponse<List<Hospital>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<List<Hospital>> apiResponse = response.body();

                    if (apiResponse.isStatus()) {
                        List<Hospital> hospitals = apiResponse.getResult();

                        setUpSpinner1(spinner_options2, hospitals);
                    }
                    else {
                        Log.d(LOG_TAG_HOSPITAL, "EMPTY DATA");
                        Toast.makeText(AppointmentReservationActivity.this, "NOT FOUND DATA", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d(LOG_TAG_HOSPITAL, "CALL API NOT SUCCESS");
                    Toast.makeText(AppointmentReservationActivity.this, "NOT FOUND DATA", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Hospital>>> call, Throwable t) {
                t.printStackTrace();
                Log.d(LOG_TAG_HOSPITAL, "CALL API FAILED");
                Toast.makeText(AppointmentReservationActivity.this, "CHECK INTERNET CONNECTION", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void callApiDepartment(int hospitalId) {
        Log.d(LOG_TAG_DEPARTMENT, "CALL API DEPARTMENT PROCESS");
        HospitalService hospitalService = ApiClient.getClient().create(HospitalService.class);
        Call<ApiResponse<List<Department>>> call = hospitalService.getDepartmentForHospital(hospitalId);

        call.enqueue(new Callback<ApiResponse<List<Department>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Department>>> call, Response<ApiResponse<List<Department>>> response) {
                if (response.isSuccessful() && response.body() != null){
                    ApiResponse<List<Department>> apiResponse = response.body();

                    if (apiResponse.isStatus()) {
                        Log.d(LOG_TAG_DEPARTMENT, "CALL API DEPARTMENT SUCCESS");
                        List<Department> departments = apiResponse.getResult();

                        setUpSpinner2(spinner_options, departments);
                    }
                    else {
                        Log.d(LOG_TAG_DEPARTMENT, "EMPTY DATA");
                        Toast.makeText(AppointmentReservationActivity.this, "NOT FOUND DATA", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d(LOG_TAG_DEPARTMENT, "EMPTY DATA - RESPONSE NOT SUCCESS");
                    Toast.makeText(AppointmentReservationActivity.this, "NOT FOUND DATA", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Department>>> call, Throwable t) {
                t.printStackTrace();
                Log.d(LOG_TAG_DEPARTMENT, "CALL API NOT SUCCESS");
                Toast.makeText(AppointmentReservationActivity.this, "NOT FOUND DATA", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadRecyclerView(List<Doctor> doctors) {
        DoctorAdapter doctorAdapter = new DoctorAdapter(doctors, this, dateString, appointmentPreInformation);

        rvDoctors.setAdapter(doctorAdapter);
        rvDoctors.setLayoutManager(new LinearLayoutManager(this));
        rvDoctors.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void setUpSpinner2(Spinner spinner, List<Department> departments) {
        DepartmentSpinnerAdapter departmentSpinnerAdapter = new DepartmentSpinnerAdapter(this, departments);
        spinner.setAdapter(departmentSpinnerAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                // Lấy đối tượng Hospital đã chọn từ Adapter
                Department selectedDepartment = (Department) parent.getItemAtPosition(position);

                if (selectedDepartment != null) {
                    Integer departmentId = selectedDepartment.getDepartmentId();
                    departmentName = selectedDepartment.getDepartmentName();

                    appointmentPreInformation.setDepartmentId(departmentId);
                    appointmentPreInformation.setDepartmentName(departmentName);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Không làm gì
            }
        });

        spinner.setSelection(0);
    }

    private void setUpSpinner1(Spinner spinner, List<Hospital> hospitals) {
        HospitalSpinnerAdapter hospitalSpinnerAdapter = new HospitalSpinnerAdapter(this, hospitals);
        spinner.setAdapter(hospitalSpinnerAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                // Lấy đối tượng Hospital đã chọn từ Adapter
                Hospital selectedHospital = (Hospital) parent.getItemAtPosition(position);

                if (selectedHospital != null) {
                    hospitalId = selectedHospital.getHospitalId();
                    String hospitalName = selectedHospital.getHospitalName();
                    appointmentPreInformation.setHospitalId(hospitalId);
                    appointmentPreInformation.setHospitalName(hospitalName);

                    if (hospitalId != -1) {
                        Log.d(LOG_TAG_HOSPITAL, hospitalId + "");
                        callApiDepartment(hospitalId);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Không làm gì
            }
        });

        spinner.setSelection(0);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showDatePickerDialog() {
        // Lấy ngày tháng hiện tại
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Tạo DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // selectedMonth bắt đầu từ 0 (0 = tháng 1), nên ta cộng 1
                        dateString = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;

                        // Hiển thị ngày đã chọn lên TextView
                        appointmentPreInformation.setAppointmentDateTime(dateString);
                        etDate.setText(dateString);
                    }
                },
                year, month, day);

        // Hiển thị dialog
        datePickerDialog.show();
    }
}