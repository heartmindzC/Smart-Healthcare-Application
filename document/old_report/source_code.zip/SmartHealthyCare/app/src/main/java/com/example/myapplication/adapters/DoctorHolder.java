package com.example.myapplication.adapters;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class DoctorHolder extends RecyclerView.ViewHolder {
    TextView tvName, tvDepartment;
    ImageButton btShowTime;
    RecyclerView rvAvailableTime;
    public DoctorHolder(@NonNull View itemView) {
        super(itemView);
        tvName = itemView.findViewById(R.id.tvName);
        tvDepartment = itemView.findViewById(R.id.tvDepartment);
        btShowTime = itemView.findViewById(R.id.btShowTime);
        rvAvailableTime = itemView.findViewById(R.id.rvAvailableTime);
    }
}
