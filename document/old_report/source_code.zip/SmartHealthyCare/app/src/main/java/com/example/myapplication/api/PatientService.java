package com.example.myapplication.api;

import com.example.myapplication.api.request.PatientRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Patient;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface PatientService {
    @POST("patients/create-patient")
    Call<ApiResponse<Patient>> create(@Body PatientRequest patientRequest);

    @GET("patients/get-patient-by-user-id/{userId}")
    Call<ApiResponse<Patient>> getPatient(@Path("userId") String userId);

    @GET("patients/get-patient-by-user-id/{userId}")
    Call<Patient> getPatientTemp(@Path("userId") String id);
}
