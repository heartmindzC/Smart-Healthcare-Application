package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Visit {
    @SerializedName("visitId")
    private int visitId;

    @SerializedName("doctorName")
    private String doctorName;

    @SerializedName("doctorId")
    private String doctorId;

    @SerializedName("visitDate")
    private String visitDate;

    @SerializedName("hospital")
    private String hospital;

    @SerializedName("department")
    private String department;

    @SerializedName("diagnosis")
    private String diagnosis;

    @SerializedName("prescriptions")

    private List<Prescription> prescriptions;

    public Visit(int visitId, String doctorName, String doctorId, String visitDate, String hospital, String department, String diagnosis, List<Prescription> prescriptions) {
        this.visitId = visitId;
        this.doctorName = doctorName;
        this.doctorId = doctorId;
        this.visitDate = visitDate;
        this.hospital = hospital;
        this.department = department;
        this.diagnosis = diagnosis;
        this.prescriptions = prescriptions;
    }

    public int getVisitId() {
        return visitId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getVisitDate() {
        return visitDate;
    }

    public String getHospital() {
        return hospital;
    }

    public String getDepartment() {
        return department;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public List<Prescription> getMedicineDescriptions() {
        return prescriptions;
    }
}
