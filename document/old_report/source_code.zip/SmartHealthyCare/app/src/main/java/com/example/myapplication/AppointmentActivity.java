package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapters.AppointmentAdapter;
import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.AppointmentService;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Appointment;
import com.example.myapplication.utilities.LoginManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AppointmentActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    FloatingActionButton fab;
    RecyclerView rvAppointment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_apointment);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        fab = findViewById(R.id.fab);
        rvAppointment = findViewById(R.id.rvAppointment);

        bottomNavigationView = findViewById(R.id.bottomNavView);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if (id == R.id.homePage){
                    changeScreen(HomeAcitivity.class);
                    return true;
                }
                else if (id == R.id.personEHRPage) {
                    changeScreen(PersonalEHRActivity.class);
                    return true;
                }
                else if (id == R.id.appointmentPage) {
                    return  true;
                }
                else if (id == R.id.profilePage) {
                    changeScreen(ProfileActivity.class);
                    return true;
                }
                return false;
            }
        });

        bottomNavigationView.setSelectedItemId(R.id.appointmentPage);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeScreen(AppointmentReservationActivity.class);
            }
        });

        callApiGetAppointment();
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
    }

    private void callApiGetAppointment() {
        AppointmentService appointmentService = ApiClient.getClient().create(AppointmentService.class);
        Call<ApiResponse<List<Appointment>>> call = appointmentService.getAppointmentByPatientId(LoginManager.getPatient().getPatientId());

        call.enqueue(new Callback<ApiResponse<List<Appointment>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Appointment>>> call, Response<ApiResponse<List<Appointment>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<List<Appointment>> apiResponse = response.body();

                    if (apiResponse.isStatus()) {
                        List<Appointment> appointments = apiResponse.getResult();

                        loadRecyclerView(appointments);
                    }
                    else{
                        Log.d("AppointmentActivity:CALL_APPOINTMENT", "RESPONSE IS NULL");
                    }
                }
                else {
                    Log.d("AppointmentActivity:CALL_APPOINTMENT", "RESPONSE IS NULL");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Appointment>>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void loadRecyclerView(List<Appointment> appointments) {
        AppointmentAdapter appointmentAdapter = new AppointmentAdapter(appointments, this);

        rvAppointment.setAdapter(appointmentAdapter);
        rvAppointment.setLayoutManager(new LinearLayoutManager(this));
        rvAppointment.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }
}