package com.example.myapplication.api;

import com.example.myapplication.api.request.AppointmentRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Appointment;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface AppointmentService {

    @POST("appointments/create")
    Call<ApiResponse<List<Appointment>>> create(@Body AppointmentRequest appointmentRequest);

    @GET("appointments/patient/{patientId}")
    Call<ApiResponse<List<Appointment>>> getAppointmentByPatientId(@Path("patientId") int patientId);

    @PATCH("appointments/confirm/{appointmentId}")
    Call<ApiResponse<List<Appointment>>> confirmAppointment(@Path("appointmentId") int appointmentId);

    @PATCH("appointments/cancel/{appointmentId}")
    Call<ApiResponse<List<Appointment>>> cancelAppointment(@Path("appointmentId") int appointmentId);
}
