package com.example.myapplication.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.models.Prescription;

import java.util.List;

public class PrescriptionAdapter extends RecyclerView.Adapter<PrescriptionHolder> {
    List<Prescription> prescriptions;

    public PrescriptionAdapter(List<Prescription> prescriptions) {
        this.prescriptions = prescriptions;
    }

    @NonNull
    @Override
    public PrescriptionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_item, parent, false);
        return new PrescriptionHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PrescriptionHolder holder, int position) {
        Prescription prescription = prescriptions.get(position);

        holder.tvMedicationName.setText(prescription.getMedicationName());
        holder.tvDosage.setText(prescription.getDosage());
        holder.tvFrequency.setText(prescription.getFrequency());
        holder.tvInstructions.setText(prescription.getInstructions());
        holder.tvQuantity.setText(String.valueOf(prescription.getQuantity()));
        holder.tvPrescribedDate.setText(prescription.getPrescribedDate().substring(0,10));
    }

    @Override
    public int getItemCount() {
        return prescriptions.size();
    }

}
