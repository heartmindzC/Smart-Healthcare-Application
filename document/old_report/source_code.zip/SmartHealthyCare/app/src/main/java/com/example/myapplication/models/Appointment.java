package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

public class Appointment {
    @SerializedName("appointmentId")
    private Integer appointmentId;

    @SerializedName("doctorId")
    private Integer doctorId;

    @SerializedName("doctorName")
    private String doctorName;

    @SerializedName("patientId")
    private Integer patientId;

    @SerializedName("patientName")
    private String patientName;

    @SerializedName("hospitalId")
    private Integer hospitalId;

    @SerializedName("hospitalName")
    private String hospitalName;

    @SerializedName("timeSlotId")
    private Integer timeSlotId;

    @SerializedName("appointmentDateTime")
    private String appointmentDateTime; // Lưu dưới dạng String ISO 8601

    @SerializedName("status")
    private String status; // Ví dụ: "PENDING"

    @SerializedName("notes")
    private String notes;

    @SerializedName("reason")
    private String reason;

    @SerializedName("createdAt")
    private String createdAt;

    @SerializedName("updatedAt")
    private String updatedAt;

    public Appointment(Integer appointmentId, Integer doctorId, String doctorName, Integer patientId, String patientName, Integer hospitalId, String hospitalName, Integer timeSlotId, String appointmentDateTime, String status, String notes, String reason, String createdAt, String updatedAt) {
        this.appointmentId = appointmentId;
        this.doctorId = doctorId;
        this.doctorName = doctorName;
        this.patientId = patientId;
        this.patientName = patientName;
        this.hospitalId = hospitalId;
        this.hospitalName = hospitalName;
        this.timeSlotId = timeSlotId;
        this.appointmentDateTime = appointmentDateTime;
        this.status = status;
        this.notes = notes;
        this.reason = reason;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public Integer getTimeSlotId() {
        return timeSlotId;
    }

    public void setTimeSlotId(Integer timeSlotId) {
        this.timeSlotId = timeSlotId;
    }

    public String getAppointmentDateTime() {
        return appointmentDateTime;
    }

    public void setAppointmentDateTime(String appointmentDateTime) {
        this.appointmentDateTime = appointmentDateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}
