package com.example.myapplication.adapters;

import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class MedicalHolder extends RecyclerView.ViewHolder {
    TextView tvDoctorName, tvVisitDate, tvDepartment, tvDiagnosis, tvViewDetail;
    RecyclerView rvPresciptions;
    HorizontalScrollView svPrescriptions;
    TextView tvMedicalName, tvDosage, tvFrequency, tvQuantity, tvInstructions, tvPrescribedDate;
    public MedicalHolder(@NonNull View itemView) {
        super(itemView);
        tvDoctorName = itemView.findViewById(R.id.tvDoctorName);
        tvVisitDate = itemView.findViewById(R.id.tvVisitDate);
        tvDepartment = itemView.findViewById(R.id.tvDepartment);
        tvDiagnosis = itemView.findViewById(R.id.tvDiagnosis);
        rvPresciptions = itemView.findViewById(R.id.rvPresciptions);
        tvViewDetail = itemView.findViewById(R.id.tvViewDetail);
        svPrescriptions = itemView.findViewById(R.id.svPrescriptions);

//        tvMedicalName     = itemView.findViewById(R.id.tvMedicalName);
//        tvDosage          = itemView.findViewById(R.id.tvDosage);
//        tvFrequency       = itemView.findViewById(R.id.tvFrequency);
//        tvQuantity        = itemView.findViewById(R.id.tvQuantity);
//        tvInstructions    = itemView.findViewById(R.id.tvInstructions);
//        tvPrescribedDate  = itemView.findViewById(R.id.tvPrescribedDate);

    }
}
