package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.UserService;
import com.example.myapplication.api.request.ChangePasswordRequest;
import com.example.myapplication.api.request.LoginRequest;
import com.example.myapplication.api.response.ChangePasswordResponse;
import com.example.myapplication.utilities.LoginManager;
import com.google.android.material.appbar.MaterialToolbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePasswordActivity extends AppCompatActivity {
    MaterialToolbar toolbar;
    EditText etOldPassword, etNewPassword, etVerifyPassword;
    Button btChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_change_password);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbar = findViewById(R.id.mbChangePassword);
        etOldPassword = findViewById(R.id.etOldPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etVerifyPassword = findViewById(R.id.etVerifyPassword);
        btChange = findViewById(R.id.btChangePassword);

        btChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newPassword = etNewPassword.getText().toString();
                String verifyPassword = etVerifyPassword.getText().toString();
                String oldPassword = etOldPassword.getText().toString();

                if (!verifyPassword.equals(newPassword)) {
                    Toast.makeText(ChangePasswordActivity.this, "Password and password verify are not same \n Please enter again", Toast.LENGTH_SHORT).show();
                    return;
                }

                callApiChangePassword(oldPassword, newPassword);
            }
        });
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void callApiChangePassword(String oldPassword, String newPassword) {
        UserService userService = ApiClient.getClient().create(UserService.class);
        Call<ChangePasswordResponse> call = userService.changePassword(new ChangePasswordRequest(LoginManager.getUser().getUserId(), oldPassword, newPassword));

        call.enqueue(new Callback<ChangePasswordResponse>() {
            @Override
            public void onResponse(Call<ChangePasswordResponse> call, Response<ChangePasswordResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ChangePasswordResponse changePasswordResponse = response.body();

                    if (changePasswordResponse.isStatus()) {
                        Toast.makeText(ChangePasswordActivity.this, "CHANGE PASSWORD SUCCESS", Toast.LENGTH_SHORT).show();
                        Log.d("ChangePasswordActivity:USER_SERVICE", "CHANGE PASSWORD SUCCESS");

                        changeScreen(HomeAcitivity.class);
                    }
                    else
                    {
                        Log.d("ChangePasswordActivity:USER_SERVICE", "STATUS IS FALSE");
                        Toast.makeText(ChangePasswordActivity.this, "CHANGE PASSWORD NOT SUCCESS", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d("ChangePasswordActivity:USER_SERVICE", "RESPONSE IS NUL");
                    Toast.makeText(ChangePasswordActivity.this, "CHANGE PASSWORD NOT SUCCESS", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ChangePasswordResponse> call, Throwable t) {
                Toast.makeText(ChangePasswordActivity.this, "INTERNET DISCONNECT", Toast.LENGTH_SHORT).show();
                t.printStackTrace();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
        finish();
    }


}