package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class User {
    @SerializedName("userId")
    private String userId;

    @SerializedName("phone")
    private String phone;

    @SerializedName("email")
    private String email;

    @SerializedName("fullname")
    private String fullname;

    @SerializedName("address")
    private String address;

    @SerializedName("birth")
    private String birth;

    @SerializedName("gender")
    private String gender;

    @SerializedName("roles")
    private List<String> roles;

    public User(String userId, String phone, String email, String fullname, String address, String birth, String gender, List<String> roles) {
        this.userId = userId;
        this.phone = phone;
        this.email = email;
        this.fullname = fullname;
        this.address = address;
        this.birth = birth;
        this.gender = gender;
        this.roles = roles;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }
}
