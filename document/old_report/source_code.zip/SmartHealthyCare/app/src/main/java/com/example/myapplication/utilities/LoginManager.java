package com.example.myapplication.utilities;

import android.content.Context;

import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.PatientService;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.EHR;
import com.example.myapplication.models.Patient;
import com.example.myapplication.models.User;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginManager {
    private static volatile LoginManager instance;
    private static User user;
    private static Patient patient;
    private static EHR ehr;

    private LoginManager() {}

    public static LoginManager getInstance() {
        if (instance == null) {
            synchronized (LoginManager.class) {
                if (instance == null) {
                    instance = new LoginManager();
                }
            }
        }
        return instance;
    }

    public static User getUser() {
        return user;
    }

    public static Patient getPatient() {
        return patient;
    }

    public static void setPatient(Patient patient) {
        LoginManager.patient = patient;
    }

    public static void setUser(User user) {
        LoginManager.user = user;
    }


    public static void clearUser() {
        LoginManager.user = null;
    }
}
