package com.example.myapplication.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.models.Visit;

import java.util.List;

public class MedicalAdapter extends RecyclerView.Adapter<MedicalHolder> {
    List<Visit> visits;
    Context context;

    public MedicalAdapter(List<Visit> visits, Context context) {
        this.visits = visits;
        this.context = context;
    }

    @NonNull
    @Override
    public MedicalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.medical_history_item, parent, false);
        return new MedicalHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicalHolder holder, int position) {
        Visit visit = visits.get(position);

        holder.tvDoctorName.setText(visit.getDoctorName());
        holder.tvDepartment.setText(visit.getDepartment());
        holder.tvDiagnosis.setText(visit.getDiagnosis());
        holder.tvVisitDate.setText(visit.getVisitDate());
        holder.tvViewDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.svPrescriptions.getVisibility() == View.VISIBLE) {
                    holder.svPrescriptions.setVisibility(View.GONE);
                }
                else {
                    holder.svPrescriptions.setVisibility(View.VISIBLE);
                }
            }
        });

        PrescriptionAdapter prescriptionAdapter = new PrescriptionAdapter(visit.getMedicineDescriptions());
        holder.rvPresciptions.setAdapter(prescriptionAdapter);
        holder.rvPresciptions.setLayoutManager(new LinearLayoutManager(context));
    }

    @Override
    public int getItemCount() {
        return visits.size();
    }
}
