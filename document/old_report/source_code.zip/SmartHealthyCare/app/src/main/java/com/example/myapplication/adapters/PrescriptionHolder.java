package com.example.myapplication.adapters;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class PrescriptionHolder extends RecyclerView.ViewHolder {
     TextView tvMedicationName;
     TextView tvDosage;
     TextView tvFrequency;
     TextView tvQuantity;
     TextView tvInstructions;
     TextView tvPrescribedDate;
    public PrescriptionHolder(@NonNull View itemView) {
        super(itemView);

        tvMedicationName = itemView.findViewById(R.id.tvMedicationName);
        tvDosage = itemView.findViewById(R.id.tvDosage);
        tvFrequency = itemView.findViewById(R.id.tvFrequency);
        tvQuantity = itemView.findViewById(R.id.tvQuantity);
        tvInstructions = itemView.findViewById(R.id.tvInstructions);
        tvPrescribedDate = itemView.findViewById(R.id.tvPrescribedDate);
    }
}
