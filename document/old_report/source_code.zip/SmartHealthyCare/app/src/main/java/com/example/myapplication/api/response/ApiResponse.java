package com.example.myapplication.api.response;

import com.example.myapplication.models.User;
import com.google.gson.annotations.SerializedName;

public class ApiResponse<T> {
    @SerializedName("status")
    private boolean status;

    @SerializedName("message")
    private String message;

    @SerializedName("result")
    private T object;

    public ApiResponse(boolean status, String message, T object) {
        this.status = status;
        this.message = message;
        this.object = object;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getResult() {
        return object;
    }

    public void setResult(T object) {
        this.object = object;
    }
}
