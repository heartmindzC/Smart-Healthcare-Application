package com.example.myapplication.models;

import java.time.LocalDate;
import java.time.LocalTime;

public class Time {
    private int doctorId;
    private String doctorName;
    private String time;
    private LocalTime startTime;
    private LocalTime endTime;
    private LocalDate date;
    private boolean isAvailable;

    public Time(String time, LocalTime startTime, LocalTime endTime, LocalDate date, boolean isAvailable) {
        this.time = time;
        this.startTime = startTime;
        this.endTime = endTime;
        this.date = date;
        this.isAvailable = isAvailable;
    }

    public Time(int doctorId, String doctorName, String time, LocalTime startTime, LocalTime endTime, LocalDate date, boolean isAvailable) {
        this.doctorId = doctorId;
        this.doctorName = doctorName;
        this.time = time;
        this.startTime = startTime;
        this.endTime = endTime;
        this.date = date;
        this.isAvailable = isAvailable;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public Time(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}
