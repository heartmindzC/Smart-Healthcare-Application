package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.PatientService;
import com.example.myapplication.api.UserService;
import com.example.myapplication.api.request.LoginRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Patient;
import com.example.myapplication.models.User;
import com.example.myapplication.utilities.LoginManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    Button btSignIn;
    EditText etUserID, etPassword;
    TextView tvClickHere;
    private final String LOG_TAG = "MainActivity:user_service";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etUserID = findViewById(R.id.etUserID);
        etPassword = findViewById(R.id.etPassword);
        btSignIn = findViewById(R.id.btSignIn);
        tvClickHere = findViewById(R.id.tvClickHere);

        tvClickHere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeScreen(SignUpActivity.class);
            }
        });

        btSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userID = etUserID.getText().toString();
                String password = etPassword.getText().toString();

                if (userID.isEmpty() || userID == null) {
                    Toast.makeText(MainActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.isEmpty() || password == null) {
                    Toast.makeText(MainActivity.this, "Please enter your password", Toast.LENGTH_SHORT).show();
                    return;
                }

                LoginRequest loginRequest = new LoginRequest(userID, password);
                login(loginRequest);
            }
        });
    }
    private void login(LoginRequest loginRequest) {
        UserService api = ApiClient.getClient().create(UserService.class);
        Call<ApiResponse<User>> callUser = api.login(loginRequest);
        callUser.enqueue(new Callback<ApiResponse<User>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<User>> call, @NonNull Response<ApiResponse<User>> response) {
                if (response.isSuccessful() && response != null) {
                    ApiResponse<User> apiResponse = response.body();
                    if (apiResponse.isStatus()) {
                        LoginManager.getInstance().setUser(apiResponse.getResult());
                        Log.d(LOG_TAG, apiResponse.getMessage());
                        changeScreen(HomeAcitivity.class);
                        setUpPatient(apiResponse.getResult());
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Email or password is wrong", Toast.LENGTH_SHORT).show();
                        Log.d(LOG_TAG, apiResponse.getMessage());
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG, "response is null, " + response.body() + ", " + response.code() + ", " + response.message());
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<User>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void setUpPatient(User user) {
        PatientService patientService = ApiClient.getClient().create(PatientService.class);
        Call<Patient> call = patientService.getPatientTemp(user.getUserId());

        call.enqueue(new Callback<Patient>() {
            @Override
            public void onResponse(Call<Patient> call, Response<Patient> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Patient patient = response.body();

                    LoginManager.getInstance().setPatient(patient);
                }
                else  {
//                    Toast.makeText(MainActivity.this, "CALL API PATIENT ERROR", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG, "CALL API ERROR");
                }
            }

            @Override
            public void onFailure(Call<Patient> call, Throwable t) {
                t.printStackTrace();
//                Toast.makeText(MainActivity.this, "CALL API PATIENT FAILED", Toast.LENGTH_SHORT).show();
                Log.d(LOG_TAG, "CALL API FAILED");
            }
        });
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(MainActivity.this, des);
        startActivity(intent);
        finish();
    }
}