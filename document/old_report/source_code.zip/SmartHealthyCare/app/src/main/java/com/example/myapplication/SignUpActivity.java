package com.example.myapplication;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.PatientService;
import com.example.myapplication.api.UserService;
import com.example.myapplication.api.request.PatientRequest;
import com.example.myapplication.api.request.SignUpRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Patient;
import com.example.myapplication.models.User;
import com.example.myapplication.utilities.LoginManager;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpActivity extends AppCompatActivity {
    private final String LOG_TAG_USER = "SignInActivity:user_service";
    private final String LOG_TAG_PATIENT = "SignInActivity:patient_service";
    EditText etPersonalID, etPhone, etEmail, etAddress, etName, etDateOfBirth, etPassword, etVerifyPassword;
    EditText etInsuranceId, etEmergencyCallingNumber, etjob, etHeight, etWeight;
    RadioGroup radioGroupGender;
    Button btSignUp1, btSignUp2, btSignUp3;
    SignUpRequest signUpRequest;
    ConstraintLayout constraintLayout2, constraintLayout, constraintLayout3;
    Spinner spinnerBloodType;
    String selectedBloodType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etPersonalID = findViewById(R.id.etPersonalID);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etName = findViewById(R.id.etName);
        etDateOfBirth = findViewById(R.id.etDateOfBirth);
        etAddress = findViewById(R.id.etAddress);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        btSignUp1 = findViewById(R.id.btSignUp1);
        constraintLayout = findViewById(R.id.constraintLayout);
        constraintLayout2 = findViewById(R.id.constraintLayout2);
        btSignUp2 = findViewById(R.id.btSignIUp2);
        etPassword = findViewById(R.id.etPassword);
        etVerifyPassword = findViewById(R.id.etVerifyPassword);
        constraintLayout3 = findViewById(R.id.constraintLayout3);
        etjob = findViewById(R.id.etjob);
        etInsuranceId = findViewById(R.id.etInsuranceId);
        etEmergencyCallingNumber = findViewById(R.id.etEmergencyCallingNumber);
        etHeight = findViewById(R.id.etHeight);
        etWeight = findViewById(R.id.etWeight);
        btSignUp3 = findViewById(R.id.btSignUp3);
        spinnerBloodType = findViewById(R.id.spinnerBloodType);

        spinnerBloodType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedBloodType = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedBloodType = "";
            }
        });

        etDateOfBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        btSignUp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String personalID = etPersonalID.getText().toString();
                if (!checkPersonalID(personalID)) {
                    Toast.makeText(SignUpActivity.this, "Personal ID is not valid", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "PersonalID not valid");
                    return;
                }

                String phone = etPhone.getText().toString();
                if (!checkPhone(phone)) {
                    Toast.makeText(SignUpActivity.this, "Phone is not valid", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Phone not valid");
                    return;
                }

                String email = etEmail.getText().toString();
                if (!checkGmail(email)) {
                    Toast.makeText(SignUpActivity.this, "Email is not valid", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Email not valid");
                    return;
                }

                String name = etName.getText().toString();
                if (!checkName(name)) {
                    Toast.makeText(SignUpActivity.this, "Name is not valid", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Name not valid");
                    return;
                }

                String dateOfBirth = etDateOfBirth.getText().toString();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (!checkDateOfBirth(dateOfBirth)) {
                        Toast.makeText(SignUpActivity.this, "Date Of birth is not valid", Toast.LENGTH_SHORT).show();
                        Log.d(LOG_TAG_USER, "Date of birth not valid");
                        return;
                    }
                }

                String address = etAddress.getText().toString();
                if (address.isEmpty() || address == null) {
                    Toast.makeText(SignUpActivity.this, "Address is not valid", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Address not valid");
                    return;
                }

                String gender = onSaveProfile();
                if (gender.isEmpty()) {
                    Toast.makeText(SignUpActivity.this, "Please select your gender", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Please select your gender");
                    return;
                }

                signUpRequest = new SignUpRequest(
                        personalID,
                        "",
                        phone,
                        email,
                        name,
                        address,
                        dateOfBirth,
                        gender);


                showLayoutCreatePassword();
            }
        });

        btSignUp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = etPassword.getText().toString();
                String verifyPassword = etVerifyPassword.getText().toString();

                if (password.isEmpty() || password == null) {
                    Toast.makeText(SignUpActivity.this, "Password is not valid", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Password not valid");
                    return;
                }

                if (!password.equals(verifyPassword)) {
                    Toast.makeText(SignUpActivity.this, "Password and verify password must similar", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG_USER, "Password and verify password must similar");
                    return;
                }

                signUpRequest.setPassword(password);
                signIn(signUpRequest);
            }
        });

        btSignUp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String insuranceID = etInsuranceId.getText().toString();
                String emergencyCallingNumber = etEmergencyCallingNumber.getText().toString();
                String job = etjob.getText().toString();
                int weight = Integer.parseInt(etWeight.getText().toString());
                int height = Integer.parseInt(etHeight.getText().toString());

                User user = LoginManager.getInstance().getUser();
                // Luu dữ liệu xuống db
                PatientRequest patientRequest = new PatientRequest(
                        user.getUserId(),
                        user.getFullname(),
                        user.getBirth(),
                        user.getGender(),
                        insuranceID,
                        emergencyCallingNumber,
                        job,
                        selectedBloodType,
                        height,
                        weight
                );
                savePatient(patientRequest);
                changeScreen(HomeAcitivity.class);
            }
        });
    }
    private void savePatient(PatientRequest patientRequest) {
        PatientService apiService = ApiClient.getClient().create(PatientService.class);
        Call<ApiResponse<Patient>> call = apiService.create(patientRequest);
        call.enqueue(new Callback<ApiResponse<Patient>>() {
            @Override
            public void onResponse(Call<ApiResponse<Patient>> call, Response<ApiResponse<Patient>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<Patient> apiResponse = response.body();
                    if (apiResponse.isStatus()) {
                        Log.d(LOG_TAG_PATIENT, apiResponse.getMessage());
                        Toast.makeText(SignUpActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Log.d(LOG_TAG_PATIENT, apiResponse.getMessage());
                        Toast.makeText(SignUpActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d(LOG_TAG_PATIENT, "Response is not successful");
                    Toast.makeText(SignUpActivity.this, "Response is not successful", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<Patient>> call, Throwable t) {
                Log.d(LOG_TAG_PATIENT, "Call API Failed");
                Toast.makeText(SignUpActivity.this, "Call API Failed", Toast.LENGTH_SHORT).show();
                t.printStackTrace();
            }
        });

    }

    private void showLayoutBasicInformation() {
        constraintLayout3.setVisibility(View.VISIBLE);
        constraintLayout2.setVisibility(View.GONE);
    }

    private void showLayoutCreatePassword() {
        constraintLayout.setVisibility(View.GONE);
        constraintLayout2.setVisibility(View.VISIBLE);
    }

    public String onSaveProfile() {
        int selectedId = radioGroupGender.getCheckedRadioButtonId();
        String gender = "";

        if (selectedId == R.id.radioButtonMale) {
            gender = "MALE";
        } else if (selectedId == R.id.radioButtonFemale) {
            gender = "FEMALE";
        }
        return gender;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkDateOfBirth(String dateString) {
        if (dateString == null) {
            return false;
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                LocalDate.parse(dateString, DateTimeFormatter.ISO_LOCAL_DATE);
            }
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    public boolean checkName(String name) {
        if (name == null) {
            return false;
        }
        String trimmedName = name.trim();
        if (trimmedName.isEmpty()) {
            return false;
        }
        String regex = "^[\\p{L} ]+$";
        return trimmedName.matches(regex);
    }

    public boolean checkGmail(String email) {
        if (email == null) {
            return false;
        }
        String processedEmail = email.trim().toLowerCase();
        return processedEmail.endsWith("@gmail.com");
    }

    private boolean checkPersonalID(String id) {
        if (id == null) {
            return false;
        }
        return id.matches("[0-9]{12}");
    }

    private boolean checkPhone(String input) {
        if (input == null) {
            return false;
        }
        return input.matches("[0-9]{10}");
    }

    private void signIn(SignUpRequest signUpRequest) {
        UserService api = ApiClient.getClient().create(UserService.class);
        Call<ApiResponse<User>> apiResponseCall = api.signIn(signUpRequest);
        apiResponseCall.enqueue(new Callback<ApiResponse<User>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<User>> call, @NonNull Response<ApiResponse<User>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<User> apiResponse = response.body();
                    if (apiResponse.isStatus()) {
                        Toast.makeText(SignUpActivity.this, apiResponse.getMessage() + "\n" + "Please Log in", Toast.LENGTH_SHORT).show();
                        Log.d(LOG_TAG_USER, apiResponse.getMessage());
                        LoginManager.getInstance().setUser(apiResponse.getResult());
                        showLayoutBasicInformation();
                    }
                    else {
                        Toast.makeText(SignUpActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                        Log.d(LOG_TAG_USER, apiResponse.getMessage());
                    }
                }
                else {
                    Log.e(LOG_TAG_USER, "Error");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<User>> call, Throwable t) {
                Log.e(LOG_TAG_USER, "Error");
                t.printStackTrace();
            }
        });
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
        finish();
    }

    private void showDatePickerDialog() {
        // Lấy ngày tháng hiện tại
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Tạo DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // selectedMonth bắt đầu từ 0 (0 = tháng 1), nên ta cộng 1
                        String dateString = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;

                        // Hiển thị ngày đã chọn lên TextView
                        etDateOfBirth.setText(dateString);
                    }
                },
                year, month, day);

        // Hiển thị dialog
        datePickerDialog.show();
    }
}