package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapters.MedicalAdapter;
import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.EHRService;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.EHR;
import com.example.myapplication.models.Visit;
import com.example.myapplication.utilities.LoginManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonalEHRActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    RecyclerView rvMedicalHistory;
    FloatingActionButton fab;
    ImageButton ibDropdownPatient;

    ConstraintLayout llPatientInformation;

    private final String LOG_TAG = "PersonalEHRActivity:";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_personal_ehr);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        bottomNavigationView = findViewById(R.id.bottomNavView);
        rvMedicalHistory = findViewById(R.id.rvMedicalHistory);
        ibDropdownPatient = findViewById(R.id.ibDropdownPatient);
        llPatientInformation = findViewById(R.id.llPatientInformation);
        fab = findViewById(R.id.fab);

        callApiEHR();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if (id == R.id.homePage){
                    changeScreen(HomeAcitivity.class);
                    return true;
                }
                else if (id == R.id.personEHRPage) {
                    return true;
                }
                else if (id == R.id.appointmentPage) {
                    changeScreen(AppointmentActivity.class);
                    return  true;
                }
                else if (id == R.id.profilePage) {
                    changeScreen(ProfileActivity.class);
                    return true;
                }
                return false;
            }
        });
        bottomNavigationView.setSelectedItemId(R.id.personEHRPage);

        ibDropdownPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (llPatientInformation.getVisibility() == View.VISIBLE) {
                    llPatientInformation.setVisibility(View.GONE);
                }
                else {
                    llPatientInformation.setVisibility(View.VISIBLE);
                }
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeScreen(AppointmentReservationActivity.class);
            }
        });
    }

    private void callApiEHR() {
        EHRService ehrService = ApiClient.getClient().create(EHRService.class);
        Call<ApiResponse<EHR>> call = ehrService.getEHR(LoginManager.getInstance().getUser().getUserId());

        call.enqueue(new Callback<ApiResponse<EHR>>() {
            @Override
            public void onResponse(Call<ApiResponse<EHR>> call, Response<ApiResponse<EHR>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<EHR> apiResponse = response.body();
                    if (apiResponse.isStatus()) {
                        loadRecyclerView(apiResponse.getResult().getVisits());
                    }
                    else {
                        Log.d(LOG_TAG, apiResponse.getMessage());
                        Toast.makeText(PersonalEHRActivity.this, LOG_TAG + apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d(LOG_TAG, "Response is null");
                    Toast.makeText(PersonalEHRActivity.this, LOG_TAG + "Response is null, " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<EHR>> call, Throwable t) {
                t.printStackTrace();
                Log.d(LOG_TAG, "Call api failed");
                Toast.makeText(PersonalEHRActivity.this, LOG_TAG + "Call API FAILED", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
    }

    private void loadRecyclerView(List<Visit> visits) {
        MedicalAdapter medicalAdapter = new MedicalAdapter(visits, this);
        rvMedicalHistory.setAdapter(medicalAdapter);
        rvMedicalHistory.setLayoutManager(new LinearLayoutManager(this));
        rvMedicalHistory.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }
}