package com.example.myapplication.api.request;

public class SignUpRequest {
    private String userId;
    private String password;
    private String phone;
    private String email;
    private String fullname;
    private String address;
    private String birth;
    private String gender;

    public SignUpRequest(String userId, String password, String phone, String email, String fullname, String address, String birth, String gender) {
        this.userId = userId;
        this.password = password;
        this.phone = phone;
        this.email = email;
        this.fullname = fullname;
        this.address = address;
        this.birth = birth;
        this.gender = gender;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
