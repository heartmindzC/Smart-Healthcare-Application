package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

public class Doctor {
    @SerializedName("doctorId")
    private Integer doctorId;

    @SerializedName("userID")
    private Integer userId;

    @SerializedName("hospitalId")
    private Integer hospitalId;

    @SerializedName("department")
    private String department;

    @SerializedName("fullName")
    private String fullName;

    @SerializedName("birth")
    private String birth; // Lưu dưới dạng String (ISO 8601 format)

    @SerializedName("registrationAt")
    private String registrationAt; // Lưu dưới dạng String (ISO 8601 format)

    @SerializedName("gender")
    private String gender;

    @SerializedName("licenseId")
    private String licenseId;

    @SerializedName("isActive")
    private Boolean isActive;

    public Doctor(Integer doctorId, Integer userId, Integer hospitalId, String department, String fullName, String birth, String registrationAt, String gender, String licenseId, Boolean isActive) {
        this.doctorId = doctorId;
        this.userId = userId;
        this.hospitalId = hospitalId;
        this.department = department;
        this.fullName = fullName;
        this.birth = birth;
        this.registrationAt = registrationAt;
        this.gender = gender;
        this.licenseId = licenseId;
        this.isActive = isActive;
    }

    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getRegistrationAt() {
        return registrationAt;
    }

    public void setRegistrationAt(String registrationAt) {
        this.registrationAt = registrationAt;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLicenseId() {
        return licenseId;
    }

    public void setLicenseId(String licenseId) {
        this.licenseId = licenseId;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }
}
