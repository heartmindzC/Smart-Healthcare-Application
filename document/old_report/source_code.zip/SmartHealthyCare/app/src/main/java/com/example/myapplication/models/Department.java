package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

public class Department {
    @SerializedName("departmentId")
    private Integer departmentId; // int -> Integer, PRI KEY

    @SerializedName("departmentEmail")
    private String departmentEmail; // varchar(255)

    @SerializedName("departmentName")
    private String departmentName; // varchar(255)

    @SerializedName("departmentPhone")
    private String departmentPhone; // varchar(255)

    @SerializedName("hospitalId")
    private Integer hospitalId;

    public Department(Integer departmentId, String departmentEmail, String departmentName, String departmentPhone, Integer hospitalId) {
        this.departmentId = departmentId;
        this.departmentEmail = departmentEmail;
        this.departmentName = departmentName;
        this.departmentPhone = departmentPhone;
        this.hospitalId = hospitalId;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentEmail() {
        return departmentEmail;
    }

    public void setDepartmentEmail(String departmentEmail) {
        this.departmentEmail = departmentEmail;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentPhone() {
        return departmentPhone;
    }

    public void setDepartmentPhone(String departmentPhone) {
        this.departmentPhone = departmentPhone;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }
}
