package com.example.myapplication.api;

import com.example.myapplication.api.request.ChangePasswordRequest;
import com.example.myapplication.api.request.LoginRequest;
import com.example.myapplication.api.request.PatientRequest;
import com.example.myapplication.api.request.SignUpRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.api.response.ChangePasswordResponse;
import com.example.myapplication.models.Patient;
import com.example.myapplication.models.User;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.PUT;

public interface UserService {
    @POST("users/login")
    Call<ApiResponse<User>> login (@Body LoginRequest loginRequest);

    @POST("users/register")
    Call<ApiResponse<User>> signIn(@Body SignUpRequest signUpRequest);

    @PUT("users/update-password")
    Call<ChangePasswordResponse> changePassword(@Body ChangePasswordRequest changePasswordRequest);

}
