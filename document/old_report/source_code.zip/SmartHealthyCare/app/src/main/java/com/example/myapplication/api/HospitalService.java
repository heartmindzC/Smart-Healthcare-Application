package com.example.myapplication.api;

import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Department;
import com.example.myapplication.models.Hospital;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface HospitalService {
    @GET("hospitals/all")
    Call<ApiResponse<List<Hospital>>> getAll();

    @GET("departments/get-departments-by-hospital/{hospitalId}")
    Call<ApiResponse<List<Department>>> getDepartmentForHospital(@Path("hospitalId") int hospitalId);
}
