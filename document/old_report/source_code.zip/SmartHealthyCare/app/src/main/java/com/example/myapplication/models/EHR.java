package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class EHR {
    @SerializedName("patientInfo")
    private Patient patientInfo;

    @SerializedName("medicalHistory")
    private List<Visit> visits;

    public EHR(Patient patientInfo, List<Visit> visits) {
        this.patientInfo = patientInfo;
        this.visits = visits;
    }

    public Patient getPatientInfo() {
        return patientInfo;
    }

    public void setPatientInfo(Patient patientInfo) {
        this.patientInfo = patientInfo;
    }

    public List<Visit> getVisits() {
        return visits;
    }

    public void setVisits(List<Visit> visits) {
        this.visits = visits;
    }
}
