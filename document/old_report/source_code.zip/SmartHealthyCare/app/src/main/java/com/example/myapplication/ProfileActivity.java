package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.models.User;
import com.example.myapplication.utilities.LoginManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;

public class ProfileActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    TextView tvName, tvAddress, tvPersonalID, tvDateOfBirth, tvPhone, tvEmail, tvGender, tvChangePass, tvSignOut;
    FloatingActionButton fab;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvName = findViewById(R.id.tvName);
        tvAddress = findViewById(R.id.tvAddress);
        tvPersonalID = findViewById(R.id.tvPersonalID);
        tvDateOfBirth = findViewById(R.id.tvDateOfBirth);
        tvPhone = findViewById(R.id.tvPhone);
        tvEmail = findViewById(R.id.tvEmail);
        tvGender = findViewById(R.id.tvGender);
        fab = findViewById(R.id.fab);
        tvChangePass = findViewById(R.id.tvChangePass);
        tvSignOut = findViewById(R.id.tvSignOut);

        user = LoginManager.getInstance().getUser();
        if (user != null) {
            tvName.setText(user.getFullname());
            tvAddress.setText(user.getAddress());
            tvPersonalID.setText(user.getUserId());
            tvDateOfBirth.setText(user.getBirth());
            tvPhone.setText(user.getPhone());
            tvEmail.setText(user.getEmail());
            tvGender.setText(user.getGender());
        }

        bottomNavigationView = findViewById(R.id.bottomNavView);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if (id == R.id.homePage){
                    changeScreen(HomeAcitivity.class);
                    return true;
                }
                else if (id == R.id.personEHRPage) {
                    changeScreen(PersonalEHRActivity.class);
                    return true;
                }
                else if (id == R.id.appointmentPage) {
                    changeScreen(AppointmentActivity.class);
                    return  true;
                }
                else if (id == R.id.profilePage) {
                    return true;
                }
                return false;
            }
        });

        bottomNavigationView.setSelectedItemId(R.id.profilePage);

        tvSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginManager.getInstance().clearUser();
                changeScreenSignOut(MainActivity.class);
            }
        });

        tvChangePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeScreen(ChangePasswordActivity.class);
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeScreen(AppointmentReservationActivity.class);
            }
        });
    }

    private void changeScreen(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
    }

    private void changeScreenSignOut(Class<?> des) {
        Intent intent = new Intent(this, des);
        startActivity(intent);
        finish();
    }
}