package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class TimeSlot {
    @SerializedName("timeSlotId")
    private Integer timeSlotId;

    @SerializedName("doctorId")
    private Integer doctorId;

    @SerializedName("dayOfWeek")
    private String dayOfWeek; // Ví dụ: "MONDAY"

    @SerializedName("startTime")
    private String startTime; // Ví dụ: "08:00:00"

    @SerializedName("endTime")
    private String endTime; // Ví dụ: "08:30:00"

    @SerializedName("isAvailable")
    private Boolean isAvailable;

    @SerializedName("specificDate")
    private String specificDate; // Có thể là null

    @SerializedName("createdAt")
    private String createdAt; // Ví dụ: "2024-11-23T10:00:00"

//    public TimeSlot(Integer timeSlotId, Integer doctorId, String dayOfWeek, LocalTime startTime, LocalTime endTime, Boolean isAvailable, LocalDate specificDate, String createdAt) {
//        this.timeSlotId = timeSlotId;
//        this.doctorId = doctorId;
//        this.dayOfWeek = dayOfWeek;
//        this.startTime = startTime;
//        this.endTime = endTime;
//        this.isAvailable = isAvailable;
//        this.specificDate = specificDate;
//        this.createdAt = createdAt;


    public TimeSlot(Integer timeSlotId, Integer doctorId, String dayOfWeek, String startTime, String endTime, Boolean isAvailable, String specificDate, String createdAt) {
        this.timeSlotId = timeSlotId;
        this.doctorId = doctorId;
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isAvailable = isAvailable;
        this.specificDate = specificDate;
        this.createdAt = createdAt;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getTimeSlotId() {
        return timeSlotId;
    }

    public void setTimeSlotId(Integer timeSlotId) {
        this.timeSlotId = timeSlotId;
    }

    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

//    public LocalTime getStartTime() {
//        return startTime;
//    }
//
//    public void setStartTime(LocalTime startTime) {
//        this.startTime = startTime;
//    }

//    public LocalTime getEndTime() {
//        return endTime;
//    }
//
//    public void setEndTime(LocalTime endTime) {
//        this.endTime = endTime;
//    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

    public String getSpecificDate() {
        return specificDate;
    }

    public void setSpecificDate(String specificDate) {
        this.specificDate = specificDate;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
