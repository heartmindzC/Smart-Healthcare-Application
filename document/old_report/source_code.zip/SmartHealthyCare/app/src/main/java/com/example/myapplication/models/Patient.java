package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

public class Patient {
    @SerializedName("patientId")
    private int patientId;

    @SerializedName("fullName")
    private String fullName;

    @SerializedName("userId")
    private String userId;

    @SerializedName("birth")
    private String birthDate;

    @SerializedName("registeredAt")
    private String registeredAt;

    @SerializedName("gender")
    private String gender;

    @SerializedName("insuranceId")
    private String insuranceId;

    @SerializedName("emergencyCallingNumber")
    private String emergencyCallingNumber;

    @SerializedName("job")
    private String job;

    @SerializedName("bloodType")
    private String bloodType;

    @SerializedName("heights")
    private double height;

    @SerializedName("weights")
    private double weight;

    @SerializedName("isActive")
    private boolean isActive;

    public Patient(int patientId, String fullName, String userId, String birthDate, String registeredAt, String gender, String insuranceId, String emergencyCallingNumber, String job, String bloodType, double height, double weight, boolean isActive) {
        this.patientId = patientId;
        this.fullName = fullName;
        this.userId = userId;
        this.birthDate = birthDate;
        this.registeredAt = registeredAt;
        this.gender = gender;
        this.insuranceId = insuranceId;
        this.emergencyCallingNumber = emergencyCallingNumber;
        this.job = job;
        this.bloodType = bloodType;
        this.height = height;
        this.weight = weight;
        this.isActive = isActive;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getRegisteredAt() {
        return registeredAt;
    }

    public void setRegisteredAt(String registeredAt) {
        this.registeredAt = registeredAt;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
    }

    public String getEmergencyCallingNumber() {
        return emergencyCallingNumber;
    }

    public void setEmergencyCallingNumber(String emergencyCallingNumber) {
        this.emergencyCallingNumber = emergencyCallingNumber;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
