package com.example.myapplication.adapters;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class AppointmentHolder extends RecyclerView.ViewHolder {
    TextView tvTime, tvStatus, tvDoctorName, tvHospitalName;

    public AppointmentHolder(@NonNull View itemView) {
        super(itemView);

        tvTime         = itemView.findViewById(R.id.tvTime);
        tvStatus       = itemView.findViewById(R.id.tvStatus);
        tvDoctorName   = itemView.findViewById(R.id.doctorName);
        tvHospitalName = itemView.findViewById(R.id.tvHospitalName);
    }
}
