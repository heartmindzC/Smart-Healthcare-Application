package com.example.myapplication.models;

import com.google.gson.annotations.SerializedName;

public class Hospital {
    @SerializedName("hospitalId")
    private Integer hospitalId; // Sử dụng Integer cho ID

    @SerializedName("hospitalName")
    private String hospitalName;

    @SerializedName("hospitalAddress")
    private String hospitalAddress;

    @SerializedName("hospitalPhone")
    private String hospitalPhone;

    @SerializedName("hospitalEmail")
    private String hospitalEmail;

    public Hospital(Integer hospitalId, String hospitalName, String hospitalAddress, String hospitalPhone, String hospitalEmail) {
        this.hospitalId = hospitalId;
        this.hospitalName = hospitalName;
        this.hospitalAddress = hospitalAddress;
        this.hospitalPhone = hospitalPhone;
        this.hospitalEmail = hospitalEmail;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getHospitalAddress() {
        return hospitalAddress;
    }

    public void setHospitalAddress(String hospitalAddress) {
        this.hospitalAddress = hospitalAddress;
    }

    public String getHospitalPhone() {
        return hospitalPhone;
    }

    public void setHospitalPhone(String hospitalPhone) {
        this.hospitalPhone = hospitalPhone;
    }

    public String getHospitalEmail() {
        return hospitalEmail;
    }

    public void setHospitalEmail(String hospitalEmail) {
        this.hospitalEmail = hospitalEmail;
    }
}
