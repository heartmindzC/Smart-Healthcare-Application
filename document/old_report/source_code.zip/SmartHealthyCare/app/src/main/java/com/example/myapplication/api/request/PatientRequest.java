package com.example.myapplication.api.request;

public class PatientRequest {
    private String userId;
    private String fullName;
    private String birth;
    private String gender;
    private String insuranceId;
    private String emergencyCallingNumber;
    private String job;
    private String bloodType;
    private int heights;
    private int weights;

    public PatientRequest(String userId, String fullName, String birth, String gender, String insuranceId, String emergencyCallingNumber, String job, String bloodType, int heights, int weights) {
        this.userId = userId;
        this.fullName = fullName;
        this.birth = birth;
        this.gender = gender;
        this.insuranceId = insuranceId;
        this.emergencyCallingNumber = emergencyCallingNumber;
        this.job = job;
        this.bloodType = bloodType;
        this.heights = heights;
        this.weights = weights;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
    }

    public String getEmergencyCallingNumber() {
        return emergencyCallingNumber;
    }

    public void setEmergencyCallingNumber(String emergencyCallingNumber) {
        this.emergencyCallingNumber = emergencyCallingNumber;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public int getHeights() {
        return heights;
    }

    public void setHeights(int heights) {
        this.heights = heights;
    }

    public int getWeights() {
        return weights;
    }

    public void setWeights(int weights) {
        this.weights = weights;
    }
}
