package com.example.myapplication.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.models.Appointment;

import java.util.List;

public class AppointmentAdapter extends RecyclerView.Adapter<AppointmentHolder> {
    List<Appointment> appointments;
    Context context;

    public AppointmentAdapter(List<Appointment> appointments, Context context) {
        this.appointments = appointments;
        this.context = context;
    }

    @NonNull
    @Override
    public AppointmentHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.appointment_item, parent, false);
        return new AppointmentHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppointmentHolder holder, int position) {
        Appointment appointment = appointments.get(position);

        holder.tvTime.setText(appointment.getAppointmentDateTime());
        holder.tvStatus.setText(appointment.getStatus());
        holder.tvDoctorName.setText(appointment.getDoctorName());
        holder.tvHospitalName.setText(appointment.getHospitalName());
    }

    @Override
    public int getItemCount() {
        return appointments.size();
    }
}
