package com.example.myapplication.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.ConfirmAppointmentActivity;
import com.example.myapplication.R;
import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.DoctorService;
import com.example.myapplication.api.request.AppointmentPreInformation;
import com.example.myapplication.api.request.TimeSlotRequest;
import com.example.myapplication.api.response.ApiResponse;
import com.example.myapplication.models.Time;
import com.example.myapplication.models.TimeSlot;

import java.time.LocalDate;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TimeAdapter extends RecyclerView.Adapter<TimeHolder> {
    private List<Time> times;
    private int timelSlotId;
    Context context;
    AppointmentPreInformation appointmentPreInformation;
    private String date;

    public TimeAdapter(List<Time> times, Context context, AppointmentPreInformation appointmentPreInformation, String date) {
        this.times = times;
        this.context = context;
        this.appointmentPreInformation = appointmentPreInformation;
        this.date = date;
    }

    @NonNull
    @Override
    public TimeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.time_item, parent, false);
        return new TimeHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TimeHolder holder, int position) {
        Time time = times.get(position);

        holder.tvTime.setText(time.getTime());

        if (!time.isAvailable()) {
            holder.itemView.setBackgroundColor(Color.parseColor("#007AFF"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (time.isAvailable()) {
                    Toast.makeText(context, "Time: " + time.getStartTime().toString() + " " + time.getEndTime().toString() + " is clicked", Toast.LENGTH_SHORT).show();


//                    appointmentPreInformation.setDoctorId(time.getDoctorId());
//                    appointmentPreInformation.setDoctorName(time.getDoctorName());
                    appointmentPreInformation.setAppointmentDateTime(null);
                    appointmentPreInformation.setAppointmentDateTime(date + "T" + time.getStartTime().toString() +":00");

                    Log.d("LOG", appointmentPreInformation.getAppointmentDateTime());

                    Toast.makeText(context, appointmentPreInformation.getAppointmentDateTime(), Toast.LENGTH_SHORT).show();
                    createTimeSlot(time);
                }
                else {
                    Toast.makeText(context, "TIME IS NOT AVAILABLE", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void createTimeSlot(Time time) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LocalDate localDate = LocalDate.parse(date);
            TimeSlotRequest timeSlotRequest = new TimeSlotRequest(
                    appointmentPreInformation.getDoctorId(),
                    localDate.getDayOfWeek().name(),
                    time.getStartTime().toString(),
                    time.getEndTime().toString(),
                    true,
                    LocalDate.parse(date).toString()
            );

            DoctorService doctorService = ApiClient.getClient().create(DoctorService.class);
            Call<ApiResponse<List<TimeSlot>>> call = doctorService.createTimeSlot(timeSlotRequest);
            call.enqueue(new Callback<ApiResponse<List<TimeSlot>>>() {
                @Override
                public void onResponse(Call<ApiResponse<List<TimeSlot>>> call, Response<ApiResponse<List<TimeSlot>>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        ApiResponse<List<TimeSlot>> apiResponse = response.body();

                        if (apiResponse.isStatus()) {
                            List<TimeSlot> timeSlots = apiResponse.getResult();
                            if (timeSlots.size() >= 1) {
                                appointmentPreInformation.setTimeSlotId(timeSlots.get(0).getTimeSlotId());
                                changeScreen(ConfirmAppointmentActivity.class, appointmentPreInformation);
                            }
                        }
                        else {
                            Log.d("CREATE TIME SLOT", "RESPONSE STATUS FALSE");
                        }
                    }
                    else {
                        Log.d("CREATE TIME SLOT", "RESPONSE IS NULL");
                    }
                }

                @Override
                public void onFailure(Call<ApiResponse<List<TimeSlot>>> call, Throwable t) {
                    t.printStackTrace();
                }
            });
        }
    }

    private void changeScreen(Class<?> des, AppointmentPreInformation appointmentPreInformation) {
        Intent intent = new Intent(context, des);
        intent.putExtra("doctorId", appointmentPreInformation.getDoctorId());
        intent.putExtra("doctorName", appointmentPreInformation.getDoctorName());
        intent.putExtra("hospitalId", appointmentPreInformation.getHospitalId());
        intent.putExtra("hospitalName", appointmentPreInformation.getHospitalName());
        intent.putExtra("departmentId", appointmentPreInformation.getDepartmentId());
        intent.putExtra("departmentName", appointmentPreInformation.getDepartmentName());
        intent.putExtra("appointmentDateTime", appointmentPreInformation.getAppointmentDateTime());
        intent.putExtra("timeSlotId", appointmentPreInformation.getTimeSlotId());
        context.startActivity(intent);
    }

    @Override
    public int getItemCount() {
        return times.size();
    }
}
