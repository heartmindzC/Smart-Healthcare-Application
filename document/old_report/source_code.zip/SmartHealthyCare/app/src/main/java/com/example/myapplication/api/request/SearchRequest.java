package com.example.myapplication.api.request;

public class SearchRequest {
    private int hospitalId;
    private String department;

    public SearchRequest(int hospitalId, String departmentName) {
        this.hospitalId = hospitalId;
        this.department = departmentName;
    }

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getDepartmentName() {
        return department;
    }

    public void setDepartmentName(String departmentName) {
        this.department = departmentName;
    }
}
