package com.example.myapplication.api.request;

import java.time.LocalDate;
import java.time.LocalTime;

public class TimeSlotRequest {
    private Integer doctorId;
    private String dayOfWeek;
    private String startTime;
    private String endTime;
    private Boolean isAvailable;
    private String specificDate;

//    public TimeSlotRequest(Integer doctorId, String dayOfWeek, LocalTime startTime, LocalTime endTime, Boolean isAvailable, LocalDate specificDate) {
//        this.doctorId = doctorId;
//        this.dayOfWeek = dayOfWeek;
//        this.startTime = startTime;
//        this.endTime = endTime;
//        this.isAvailable = isAvailable;
//        this.specificDate = specificDate;
//    }


    public TimeSlotRequest(Integer doctorId, String dayOfWeek, String startTime, String endTime, Boolean isAvailable, String specificDate) {
        this.doctorId = doctorId;
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isAvailable = isAvailable;
        this.specificDate = specificDate;
    }

    public Integer getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Integer doctorId) {
        this.doctorId = doctorId;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

//    public LocalTime getStartTime() {
//        return startTime;
//    }
//
//    public void setStartTime(LocalTime startTime) {
//        this.startTime = startTime;
//    }
//
//    public LocalTime getEndTime() {
//        return endTime;
//    }
//
//    public void setEndTime(LocalTime endTime) {
//        this.endTime = endTime;
//    }


    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setSpecificDate(String specificDate) {
        this.specificDate = specificDate;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

//    public LocalDate getSpecificDate() {
//        return specificDate;
//    }
//
//    public void setSpecificDate(LocalDate specificDate) {
//        this.specificDate = specificDate;
//    }
}
